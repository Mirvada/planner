<script setup lang="ts">
  import Pomodoro from '@/components/Pomodoro.vue';
</script>

<template>
  <Pomodoro />
</template>

<style>
  * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }
</style>
