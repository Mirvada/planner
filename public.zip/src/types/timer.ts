export type TimerOptionKey = 'focus' | 'shortPause' | 'longPause';
