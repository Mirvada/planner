export const convertMinutesToMS = (minute: number): number => minute * 60 * 1000;
